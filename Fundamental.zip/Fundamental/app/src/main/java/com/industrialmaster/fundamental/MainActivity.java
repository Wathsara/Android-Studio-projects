package com.industrialmaster.fundamental;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.security.PublicKey;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this,"Created.......",Toast.LENGTH_SHORT).show();

    }

    public void start(View v){
        Intent svc = new Intent(this,SoundService.class);
        startService(svc);

    }

    public void stop(View v){
        Intent sng =new Intent(this,SoundService.class);
        stopService(sng);

    }
}
